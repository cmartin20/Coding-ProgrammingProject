﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BookManagement {
    /// <summary>
    /// Interaction logic for AddEditPersonDialog.xaml
    /// </summary>
    public partial class AddEditPersonDialog : Window {

        public AddEditPersonDialog(Person personToEdit) {
            InitializeComponent();
            // personToEdit will be left null if we're adding a new person, rather than editing existing
            if (personToEdit != null) {
                txtPersonName.Text = personToEdit.Name;
                chkIsTeacher.IsChecked = personToEdit.IsTeacher;
            }
        }

        public string PersonName;

        public Boolean IsTeacher;

        private void btnCancel_Click(object sender, RoutedEventArgs e) {
            this.DialogResult = false;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e) {
            if (txtPersonName.Text == null || txtPersonName.Text.Equals("")) {
                MessageBox.Show("Please enter a name for the person");
            } else {
                PersonName = txtPersonName.Text;
                IsTeacher = (chkIsTeacher.IsChecked == true);
                this.DialogResult = true;
            }
        }
    }
}
