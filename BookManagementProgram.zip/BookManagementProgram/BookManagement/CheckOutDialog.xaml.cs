﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BookManagement {
    /// <summary>
    /// Interaction logic for CheckOutDialog.xaml
    /// </summary>
    public partial class CheckOutDialog : Window {

        public CheckOutDialog(Book _bookToCheckout, List<Person> people, int teacherLimit, int studentLimit) {
            InitializeComponent();
            bookToCheckout = _bookToCheckout;
            peopleToPickFrom = people;
            teacherDaysLimit = teacherLimit;
            studentDaysLimit = studentLimit;
            lblBookTitle.Content = bookToCheckout.Title;
            cboBorrower.ItemsSource = peopleToPickFrom;
        }

        private Book bookToCheckout;
        private List<Person> peopleToPickFrom;
        private int teacherDaysLimit;
        private int studentDaysLimit;

        public Person Borrower;
        public DateTime DueDate;

        private void cboBorrower_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (cboBorrower.SelectedItem != null) {
                Borrower = cboBorrower.SelectedItem as Person;
                lblIsTeacher.Content = Borrower.IsTeacher ? "Yes" : "No";
                if (Borrower.IsTeacher) {
                    lblDueDate.Content = DateTime.Now.AddDays(teacherDaysLimit).ToShortDateString();
                    lblDaysTillDue.Content = teacherDaysLimit.ToString();
                } else {
                    lblDueDate.Content = DateTime.Now.AddDays(studentDaysLimit).ToShortDateString();
                    lblDaysTillDue.Content = studentDaysLimit.ToString();
                }
            }
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e) {
            this.DialogResult = false;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e) {
            if (cboBorrower.SelectedItem == null) {
                MessageBox.Show("Please select a borrower");
            } else {
                Borrower = cboBorrower.SelectedItem as Person;
                if (Borrower.IsTeacher) {
                    DueDate = DateTime.Now.AddDays(teacherDaysLimit);
                } else {
                    DueDate = DateTime.Now.AddDays(studentDaysLimit);
                }
                this.DialogResult = true;
            }
        }

        
    }
}
