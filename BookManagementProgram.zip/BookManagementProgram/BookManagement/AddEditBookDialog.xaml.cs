﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BookManagement {
    /// <summary>
    /// Interaction logic for AddEditBookDialog.xaml
    /// </summary>
    public partial class AddEditBookDialog : Window {

        public AddEditBookDialog() {
            // Dialog to add a new book
            InitializeComponent();
            NumCopiesPanel.Visibility = Visibility.Visible;
        }

        public AddEditBookDialog(Book bookToEdit) {
            // Dialog to edit an existing book
            InitializeComponent();
            txtBookTitle.Text = bookToEdit.Title;
            txtAuthor.Text = bookToEdit.Author;
            // Don't show "num copies" option when editing rather than adding
            NumCopiesPanel.Visibility = Visibility.Hidden;
        }

        public String BookTitle;

        public String BookAuthor;

        public int numCopiesToAdd;

        private void btnCancel_Click(object sender, RoutedEventArgs e) {
            this.DialogResult = false;
        }

        private void btnSave_Click(object sender, RoutedEventArgs e) {

            if (txtBookTitle.Text == null || txtBookTitle.Text.Equals("")) {
                MessageBox.Show("Please enter a book title.");
            } else if (txtAuthor.Text == null || txtAuthor.Text.Equals("")) {
                MessageBox.Show("Please enter an author.");
            } else if (!Int32.TryParse(txtNumCopiesToAdd.Text, out numCopiesToAdd)) {
                MessageBox.Show("Number of copies must be an integer.");
            } else {
                BookTitle = txtBookTitle.Text;
                BookAuthor = txtAuthor.Text;
                numCopiesToAdd = Int32.Parse(txtNumCopiesToAdd.Text);
                this.DialogResult = true;
            }
            
        }
    }
}
