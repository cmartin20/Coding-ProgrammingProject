﻿
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BookManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow() {
            InitializeComponent();
            if (File.Exists("SavedData.txt")) {
                LoadData();
            }
            lstBooks.ItemsSource = theBooks;  // Hook the list up to the collection
            lstPeople.ItemsSource = thePeople;
        }

        public double dailyFine = 0.05;

        List<Book> theBooks = new List<Book>();

        List<Person> thePeople = new List<Person>();

        static int lastBookId = 0;

        private int getNewBookID() {
            lastBookId = lastBookId + 1;
            return lastBookId;
        }

        private void btnAddBook_Click(object sender, RoutedEventArgs e) {
            AddEditBookDialog addBookDialog = new AddEditBookDialog();
            // Show the dialog, and if they didn't click cancel on it...
            if (addBookDialog.ShowDialog() == true) {
                for (int i = 0; i < addBookDialog.numCopiesToAdd; i++) {
                    Book newBook = new Book();
                    newBook.Title = addBookDialog.BookTitle;
                    newBook.Author = addBookDialog.BookAuthor;
                    newBook.BookID = getNewBookID();
                    theBooks.Add(newBook);
                }
                lstBooks.Items.Refresh();  // Refresh the listbox of books
                SaveData();
            }
        }

        private void btnEditBook_Click(object sender, RoutedEventArgs e) {
            if (lstBooks.SelectedItem != null) {
                Book selectedBook = (lstBooks.SelectedItem as Book);
                // Provide the selectedBook as an argument, this constructor creates an "edit" dialog
                AddEditBookDialog editBookDialog = new AddEditBookDialog(selectedBook);
                // Show the dialog, and if they didn't click cancel on it...
                if (editBookDialog.ShowDialog() == true) {
                    selectedBook.Title = editBookDialog.BookTitle;
                    selectedBook.Author = editBookDialog.BookAuthor;
                    lstBooks.Items.Refresh();  // Refresh the listbox of books
                    lstBooks_SelectionChanged(null, null);  // Update the labels and enable/disable checkout button
                    SaveData();
                }
            }
        }

        private void btnDeleteBook_Click(object sender, RoutedEventArgs e) {
            if (lstBooks.SelectedItem != null) {
                Book selectedBook = (lstBooks.SelectedItem as Book);
                theBooks.Remove(selectedBook);
                lstBooks.Items.Refresh();  // Refresh the listbox of books
                SaveData();
            }
        }

        private void btnReturnBook_Click(object sender, RoutedEventArgs e) {
            if (lstBooks.SelectedItem != null) {
                Book selectedBook = (lstBooks.SelectedItem as Book);
                selectedBook.Borrower = null;
                selectedBook.DueDate = DateTime.Now;
                lstBooks.Items.Refresh();  // Refresh the listbox of books
                lstBooks_SelectionChanged(null, null);  // Update the labels and enable/disable checkout button
                lstPeople_SelectionChanged(null, null);  // Update the labels
                SaveData();
            }
        }

        private void btnCheckOut_Click(object sender, RoutedEventArgs e) {
            if (thePeople.Count == 0) {
                MessageBox.Show("You must add at least one person before books can be checked out.  See the 'People' tab above.");
            } else {
                if (lstBooks.SelectedItem != null) {
                    Book selectedBook = (lstBooks.SelectedItem as Book);
                    if (selectedBook.Borrower == null) {
                        // Make sure the user has valid integers (something) in the limits textboxes.
                        int i = 0;
                        if (!int.TryParse(txtStudentLimit.Text, out i)) {
                            txtStudentLimit.Text = "15";
                        }
                        if (!int.TryParse(txtTeacherLimit.Text, out i)) {
                            txtTeacherLimit.Text = "20";
                        }
                        int teacherDaysLimit = int.Parse(txtTeacherLimit.Text);
                        int studentDaysLimit = int.Parse(txtStudentLimit.Text);

                        CheckOutDialog checkOutDialog = new CheckOutDialog(selectedBook, thePeople, teacherDaysLimit, studentDaysLimit);
                        if (checkOutDialog.ShowDialog() == true) {
                            selectedBook.Borrower = checkOutDialog.Borrower;
                            selectedBook.DueDate = checkOutDialog.DueDate;
                            lstBooks.Items.Refresh();  // Refresh the listbox of books
                            lstBooks_SelectionChanged(null, null);  // Update the labels and enable/disable checkout button
                            lstPeople_SelectionChanged(null, null);  // Update the labels
                            SaveData();
                        }
                    }
                }
            }
        }

        private void lstBooks_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            
            if (lstBooks.SelectedItem != null) {

                Book selectedBook = (lstBooks.SelectedItem as Book);

                lblBookTitle.Content = selectedBook.Title;
                lblAuthor.Content = selectedBook.Author;
                lblBookID.Content = selectedBook.BookID;
                if (selectedBook.Borrower != null) {
                    lblCheckedOut.Content = selectedBook.Borrower.Name;
                    lblDaysTillDue.Content = selectedBook.DaysTillDue;
                } else {
                    lblCheckedOut.Content = "In Library";
                    lblDaysTillDue.Content = "N/A";
                }

                // Can't click delete, edit, or check out, unless you have a book selected
                btnEditBook.IsEnabled = true;
                btnDeleteBook.IsEnabled = true;
                // Can't check out a book if someone else already has it checked out
                if (selectedBook.Borrower != null) {
                    btnCheckOut.IsEnabled = false;
                    btnReturnBook.IsEnabled = true;
                } else {
                    btnCheckOut.IsEnabled = true;
                    btnReturnBook.IsEnabled = false;
                }
            } else {

                // Nothing is selected anymore, zero these labels out
                lblBookTitle.Content = "";
                lblAuthor.Content = "";
                lblBookID.Content = "";
                lblCheckedOut.Content = "";
                lblDaysTillDue.Content = "";

                // Can't click delete, edit, or check out, unless you have a book selected
                btnEditBook.IsEnabled = false;
                btnDeleteBook.IsEnabled = false;
                btnCheckOut.IsEnabled = false;
                btnReturnBook.IsEnabled = false;
            }

        }

        /*
         * People Tab ----------------
         */

        private void btnEditPerson_Click(object sender, RoutedEventArgs e) {
            if (lstPeople.SelectedItem != null) {
                Person selectedPerson = (lstPeople.SelectedItem as Person);
                // Provide the selectedPerson as an argument, this constructor creates an "edit" dialog
                AddEditPersonDialog editPersonDialog = new AddEditPersonDialog(selectedPerson);
                // Show the dialog, and if they didn't click cancel on it...
                if (editPersonDialog.ShowDialog() == true) {
                    selectedPerson.Name = editPersonDialog.PersonName;
                    selectedPerson.IsTeacher = editPersonDialog.IsTeacher;
                    lstPeople.Items.Refresh();  // Refresh the listbox of people
                    lstPeople_SelectionChanged(null, null);  // Update the labels
                    SaveData();
                }
            }
        }

        private void btnDeletePerson_Click(object sender, RoutedEventArgs e) {
            if (lstPeople.SelectedItem != null) {
                Person selectedPerson = (lstPeople.SelectedItem as Person);
                thePeople.Remove(selectedPerson);
                lstPeople.Items.Refresh();  // Refresh the listbox of people

                foreach (Book book in theBooks) {
                    if (book.Borrower == selectedPerson) {
                        book.Borrower = null;
                        book.DueDate = DateTime.Now;
                    }
                }
                lstBooks.Items.Refresh();  // Refresh the books display
                SaveData();
            }
        }

        private void btnAddPerson_Click(object sender, RoutedEventArgs e) {

            AddEditPersonDialog addPersonDialog = new AddEditPersonDialog(null); // Just give null, since we're adding, not editting
            // Show the dialog, and if they didn't click cancel on it...
            if (addPersonDialog.ShowDialog() == true) {
                Person newPerson = new Person();
                newPerson.Name = addPersonDialog.PersonName;
                newPerson.IsTeacher = addPersonDialog.IsTeacher;

                thePeople.Add(newPerson);
                lstPeople.Items.Refresh();  // Refresh the listbox of people
                SaveData();
            }
        }

        private void lstPeople_SelectionChanged(object sender, SelectionChangedEventArgs e) {
            if (lstPeople.SelectedItem != null) {

                Person selectedPerson = (lstPeople.SelectedItem as Person);

                lblPersonName.Content = selectedPerson.Name;
                lblIsTeacher.Content = selectedPerson.IsTeacher ? "Yes" : "No";

                int numCheckedOut = 0;
                foreach (Book book in theBooks) {
                    if (book.Borrower == selectedPerson) {
                        numCheckedOut = numCheckedOut + 1;
                    }
                }
                lblNumCheckedOut.Content = numCheckedOut.ToString();

                // Can't click delete, edit, or check out, unless you have a Person selected
                btnEditPerson.IsEnabled = true;
                btnDeletePerson.IsEnabled = true;
            } else {

                // Nothing is selected anymore, zero these labels out
                lblPersonName.Content = "";
                lblIsTeacher.Content = "";
                lblNumCheckedOut.Content = "";

                // Can't click delete, edit, or check out, unless you have a Person selected
                btnEditPerson.IsEnabled = false;
                btnDeletePerson.IsEnabled = false;
            }
        }

        // Restrict to only numbers
        private void PreviewTextInput(object sender, TextCompositionEventArgs e) {
            int i = 0;
            bool result = int.TryParse(e.Text.ToString(), out i);

            if (result == false) {
                e.Handled = true;
            }
        }

        /* 
         * Reports
         */

        private void btnLoanedBooksReport_Click(object sender, RoutedEventArgs e) {
            Stream myStream;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.txt)|*.txt";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == true) {
                if ((myStream = saveFileDialog1.OpenFile()) != null) {
                    StreamWriter writer = new StreamWriter(myStream);

                    foreach (Person person in thePeople) {
                        writer.WriteLine(person.Name + ":");
                        foreach (Book book in theBooks) {
                            if(book.Borrower == person) {
                                writer.WriteLine("\t" + book.Title + "\tDays till due: " + book.DaysTillDue);
                            }
                        }
                        writer.WriteLine();
                    }

                    writer.Close();
                }
                // Launch/open the file
                Process.Start(saveFileDialog1.FileName);
            }
        }

        private void btnFinesReport_Click(object sender, RoutedEventArgs e) {
            Stream myStream;
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();

            saveFileDialog1.Filter = "txt files (*.txt)|*.txt";
            saveFileDialog1.FilterIndex = 2;
            saveFileDialog1.RestoreDirectory = true;

            if (saveFileDialog1.ShowDialog() == true) {
                if ((myStream = saveFileDialog1.OpenFile()) != null) {
                    StreamWriter writer = new StreamWriter(myStream);

                    foreach (Person person in thePeople) {
                        writer.WriteLine(person.Name + "'s overdue books:");
                        double totalFine = 0; 
                        foreach (Book book in theBooks) {
                            if (book.Borrower == person && book.DaysTillDue < 0) {
                                writer.WriteLine("\t" + book.Title);
                                totalFine += -(book.DaysTillDue * dailyFine);
                            }
                            
                        }
                        writer.WriteLine("Total Fine: " + totalFine.ToString("$0.00"));
                        writer.WriteLine();
                    }

                    writer.Close();
                }
                // Launch/open the file
                Process.Start(saveFileDialog1.FileName);
            }
        }

        /*
         * Saving and Loading data
         */

        private void SaveData() {
            try {
                using (StreamWriter outFile = new StreamWriter("SavedData.txt")) {
                    outFile.WriteLine(lastBookId);
                    outFile.WriteLine(thePeople.Count);
                    outFile.WriteLine(theBooks.Count);
                    foreach (Person person in thePeople) {
                        outFile.WriteLine(person.Name + ',' + person.IsTeacher);
                    }
                    foreach (Book book in theBooks) {
                        outFile.WriteLine(book.Title + ',' + book.Author + ',' + book.BookID + ',' + book.Borrower + ',' + book.DueDate);
                    }
                }
                // Save the Lists theBooks and thePeople to a file on disk somewhere.
               
                } 
            catch(Exception e) {
                MessageBox.Show("Save Failed");
                }
            }

        private void LoadData() {
            using (StreamReader inFile = new StreamReader("SavedData.txt")) {
                lastBookId = Convert.ToInt32(inFile.ReadLine());
                int numPeople = Convert.ToInt32(inFile.ReadLine());
                int numBooks = Convert.ToInt32(inFile.ReadLine());
                for (int i = 0; i < numPeople; i++) {
                    char[] delim = { ',' };
                    string[] Data = inFile.ReadLine().Split(delim);
                    Person loaded = new Person();
                    loaded.Name = Data[0];
                    if (Data[1] == "True") {
                        loaded.IsTeacher = true;
                    } else {
                        loaded.IsTeacher = false;
                    }
                    thePeople.Add(loaded);
                }
                for (int i = 0; i < numBooks; i++) {
                    char[] delim = { ',' };
                    string[] Data = inFile.ReadLine().Split(delim);
                    Book loaded = new Book();
                    loaded.Title = Data[0];
                    loaded.Author = Data[1];
                    loaded.BookID = Convert.ToInt32(Data[2]);
                    foreach (Person person in thePeople) {
                        if (Data[3] == person.Name) {
                            loaded.Borrower = person;
                            break;
                        }
                    }
                    delim = new char[] { '/', ' ' };
                    string[] Date = Data[4].Split(delim);
                    loaded.DueDate = new DateTime(Convert.ToInt32(Date[2]), Convert.ToInt32(Date[0]), Convert.ToInt32(Date[1]));
                    theBooks.Add(loaded);
                }
            }
            // Load the Lists theBooks and thePeople from a file on disk somewhere.

        }

        private void btnHelp_Click(object sender, RoutedEventArgs e) {
            MessageBox.Show("To add a book into the program click the add book button, then type in all the information about the book you want to add. To save your entered data click ok.\n\nYou can use the edit button to edit a book that's already in the program. First select the book and click the edit book button. Then type in the new information and click ok.\n\nTo delete a book first select it and then hit the delete button. This will remove from the program and remove it from the checkout list.\n\nTo check out a book you must first add people into the program in the people tab. Then select the book you want to check out and click the check out button. Finally, select the person who is going to check out the book and click ok.\n\nTo return a book first select a book and then click the return button. This will remove it from the loaned books report.\n\nClicking the loaned books report will generate a report that says what books are checked out, who has them checked out, and the days till due.\n\nClicking the fines report button will generate a report that says how much each person owes in fines." );
        }

        private void btnHelp2_Click(object sender, RoutedEventArgs e) {
            MessageBox.Show("To add a person into the program click on the add person button and enter their name and information. Then click the ok button.\n\nTo edit a person in the program, first select the person, then click the edit button and edit the fields that you wish. Then click the ok button.\n\nTo remove a person, first select the person, and then click the remove button. This will remove them from the program and return all of their checked out books.\n\nYou may enter a value for both students and teacher at the bottom for the number of days until their books are due.");
        }
    }
}
