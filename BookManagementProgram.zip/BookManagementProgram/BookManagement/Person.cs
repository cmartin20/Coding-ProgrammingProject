﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagement
{
    public class Person
    {

        private string name;
        private Boolean isTeacher;

        public override string ToString() {
            return name;
        }

        public string Name {
            get {
                return name;
            }

            set {
                name = value;
            }
        }

        public bool IsTeacher {
            get {
                return isTeacher;
            }

            set {
                isTeacher = value;
            }
        }
    }
}
