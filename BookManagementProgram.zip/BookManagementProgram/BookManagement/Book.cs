﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BookManagement
{
    public class Book
    {

        private string title;
        private string author;
        private int bookID;
        private Person borrower;
        private DateTime dueDate;

        public override string ToString() {
            return title;
        }

        public int DaysTillDue {
            get {
                return (dueDate - DateTime.Now).Days;
            }
        }

        public DateTime DueDate {
            get {
                return dueDate;
            }

            set {
                dueDate = value;
            }
        }

        public Person Borrower {
            get {
                return borrower;
            }

            set {
                borrower = value;
            }
        }

        public int BookID {
            get {
                return bookID;
            }

            set {
                bookID = value;
            }
        }

        public string Author {
            get {
                return author;
            }

            set {
                author = value;
            }
        }

        public string Title {
            get {
                return title;
            }

            set {
                title = value;
            }
        }
    }
}
